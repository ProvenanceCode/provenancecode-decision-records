# ProvenanceCode AI Rules (Starter Pack)

Purpose: ensure high-impact changes are logged as decisions before
implementation.

## Decision logging triggers
Create a decision draft before implementing changes that are:
- Architectural or cross-cutting
- Security, privacy, or compliance related
- Governance or policy related
- Changes to `src/`, `infra/`, `security/`, or `provenance/schema/`

## Draft workflow
1) Create a draft in `provenance/drafts/DEC-XXXXXX-draft.md`.
2) Fill in the template (problem, options, outcome, risks).
3) Confirm the decision with a human reviewer.
4) Finalize by creating `provenance/decisions/DEC-XXXXXX/decision.json`
   and `provenance/decisions/DEC-XXXXXX/decision.md`.

## Decision ID format
- Use `DEC-000001` format.
- Include the ID in PR title, description, or commit message.

## Non-blocking scope
Drafts are allowed for early-stage discussion. Enforcement is handled by
the validator when enabled in config.
