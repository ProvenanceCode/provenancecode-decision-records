# ProvenanceCode Cursor Starter Pack

Copy this folder into the root of another repository to test how Cursor handles
decision rules and draft creation.

## What this includes
- `.cursor/rules.md` (Cursor project rules)
- `.provenancecode/ai-rules.md` (decision logging rules)
- `provenance/config.json` (rules for enforcement triggers)
- `provenance/drafts/` (draft template)
- `provenance/decisions/DEC-000001/` (example decision record)

## Quick start
1) Copy all contents of this folder into the target repo root.
2) Open the repo in Cursor and confirm "Use Project Rules" is enabled.
3) Ask Cursor to make a change in `src/` or `security/` to trigger the rules.
4) Cursor should propose a decision draft under `provenance/drafts/`.

## Notes
- The example acceptance receipt uses placeholder hashes and commit SHA.
- Replace `DEC-000001` with your real decision ID.
- Drafts live under `provenance/drafts/` and are not enforced.
