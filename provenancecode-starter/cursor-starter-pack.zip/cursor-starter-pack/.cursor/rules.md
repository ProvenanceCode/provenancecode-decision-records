# Cursor Project Rules (Starter Pack)

These rules support decision logging via ProvenanceCode.

## When to log a decision
- Any change in `src/`, `infra/`, `security/`, or `provenance/schema/`.
- Any change that impacts architecture, security, or data governance.

## Drafts
- Create drafts in `provenance/drafts/DEC-XXXXXX-draft.md`.
- Use the template in `provenance/drafts/README.md`.

## Final decisions
- Final decisions live in `provenance/decisions/DEC-XXXXXX/`.
- Required files: `decision.json` and `decision.md`.
- Accepted decisions also include `acceptance.receipt.json`.

## IDs
- Decision IDs must match `DEC-000001` format.
