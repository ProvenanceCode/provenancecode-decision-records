# DEC-000001 - Adopt decision records starter pack

## Summary
Adopt a minimal decision record structure to support Cursor-driven decision
drafting and review.

## Outcome
Use the ProvenanceCode decision record format for decisions that impact
architecture, security, or governance.
