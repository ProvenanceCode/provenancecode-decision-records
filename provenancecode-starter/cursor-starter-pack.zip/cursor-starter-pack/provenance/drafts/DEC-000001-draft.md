# DEC-000001 Draft - ProvenanceCode Starter Pack

## Context
We need a consistent place to log decisions when using Cursor and GitHub.

## Options
1) Keep decisions in ad-hoc notes
2) Adopt a decision record structure in the repo

## Outcome
Adopt the decision record structure with a simple starter pack.

## Risks
Low risk. The initial version is documentation-first and easy to revise.

## Next steps
- Create `decision.json` and `decision.md`
- Capture acceptance receipt after approval
