# Draft Decision Template

Use this template for early-stage decision drafts. Drafts are not enforced.

## Decision ID
DEC-000001

## Context
- Problem statement
- Why now
- Constraints

## Options
1) Option A
2) Option B
3) Option C

## Outcome
- Chosen option and rationale

## Risks
- Risk level (low, medium, high)
- Mitigations

## Next steps
- What must happen to finalize the decision
